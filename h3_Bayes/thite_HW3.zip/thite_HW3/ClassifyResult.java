
public class ClassifyResult {
	
	public String label; 	
	public double posteriorProb;
	
}
