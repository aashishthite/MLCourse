import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Feature 
{
	public String featureName;
	public boolean isNumeric;
	public double threshold;
}
